class student:
  def __init__(self,first,last,dist,cred):
    self.first = first
    self.last = last
    self.dist = dist
    self.cred = cred
    if dist == 'I':
      tuit = cred * 250.00
    elif dist =='O':
      tuit = cred * 500.00
    self.tuit = tuit

  
  

stu1 = student('Alejandro','Ducatenzeiler','I',5)

print(stu1.first)
print(stu1.last)
print(stu1.dist)
print(stu1.cred)
print(stu1.tuit)
