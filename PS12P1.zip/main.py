class Employee:
  def __init__(self,first,last,pay,rate):
    self.first = first
    self.last = last
    self.pay = pay
    self.rate = rate 
    self.email = first + '.' + last + '@company.com'
    self.bonus = rate * pay
  
  

empl1 = Employee('Alejandro','Ducatenzeiler',50000.00,0.10)

print(empl1.email)
print(empl1.first)
print(empl1.last)
print(empl1.pay)
print(empl1.bonus)
